var canvas;
var stage;
var bmpAnimation;
var callback;
var ninjaEffect = new Image();

function posiziona(el) {
	var x = $(el).offset().left;
	var y = $(el).offset().top;
	var w = $(el).width();
	var h = $(el).height();
	if(w > 113) {
		var new_x = (w - 113) / 2;
	} else {
		var new_x = (113 - w) / 2;
	}
	
	if(h > 133) {
		var new_y = (h - 133) / 2;
	} else {
		var new_y = (133 - h) / 2;
	}
	$("#ninjaEffect").css("top",(h > 133) ? y+new_y : y-new_y);
	$("#ninjaEffect").css("left",(w > 113) ? x+new_x : x-new_x);
	$("#ninjaEffect").show();
}
function handleImageError(e) {
	alert("Caricamento immagine non riuscito: " + e.target.src);
}
function tick() {
	stage.update();
}	
function doEffect() {
	stage = new createjs.Stage(canvas);
	var spriteSheet = new createjs.SpriteSheet({
		images: [ninjaEffect],
		frames: { width: 113, height: 133, regX: 0, regY: 0 },
		animations: {
			doNinja: [0, 4, "", 6]
		}
	});
	bmpAnimation = new createjs.BitmapAnimation(spriteSheet);
	bmpAnimation.gotoAndPlay("doNinja");
	bmpAnimation.currentFrame = 0;
	bmpAnimation.onAnimationEnd = closeCanvas;
	stage.addChild(bmpAnimation);
	createjs.Ticker.addListener(window);
	createjs.Ticker.useRAF = true;
	createjs.Ticker.setFPS(60);
}
function closeCanvas() {
	$(canvas).hide();
	if(callback) {
		callback();
		callback = false;
	}
}
$(function($){
	$.fn.ninja = function() {
		var args = arguments[0] || {};
		var element = this[0];
		var reverse = args.reverse || false;
		var ninjaPath = args.ninjaPath || "images/ninja.png";
		callback = (typeof args.callback == 'function') ? args.callback : false;
		if($("#ninjaEffect").length == 0) {
			$("body").prepend("<canvas id='ninjaEffect' width='113' height='133' style='position: absolute; top: 0; left: 0; z-index: 1; display: none;'>Il tuo browser non supporta Canvas.</canvas>");
		}
		canvas = document.getElementById("ninjaEffect");
		posiziona(element);
		ninjaEffect.onload = doEffect;
		ninjaEffect.onerror = handleImageError;
		ninjaEffect.src = ninjaPath;
		if(typeof reverse == 'undefined' || reverse == 0 || reverse === false || reverse == '') {
			$(element).css("visibility","hidden");
		} else {
			$(element).css("visibility","visible");
		}
	};
});